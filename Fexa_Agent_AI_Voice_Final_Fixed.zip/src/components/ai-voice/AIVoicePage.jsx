import React from "react";
import {
  ArrowRight,
  Bot,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Globe2,
  Link2,
  MessageCircle,
  Mic2,
  MoreHorizontal,
  Phone,
  Plug,
  Send,
  Share2,
  Sparkles,
  Users,
  Volume2,
  X,
  Zap,
} from "lucide-react";
import "./AIVoicePage.css";
import { FaFacebookF, FaInstagram } from "react-icons/fa";

const useCases = [
  ["E-commerce Stores", "Guide to products, increase sales"],
  ["Service Businesses", "Answer questions, book appointments"],
  ["Healthcare & Clinics", "Schedule appointments, provide info"],
  ["Real Estate", "Share listings and property details"],
  ["Education", "Answer inquiries, guide students"],
];

const features = [
  [Mic2, "Natural & Human-like Voice", "Realistic, natural, and engaging voice conversations."],
  [Globe2, "Multi-language Support", "Talk in 100+ languages. Customer speaks in their language, agent replies in the same language."],
  [Sparkles, "Smart Page & Product Navigation", "If visitors can't find a page or product, voice agent automatically searches and takes them to the right page."],
  [Share2, "Social Media Connection", "Connect with Facebook, Instagram, WhatsApp, Messenger and more directly from the widget."],
  [MessageCircle, "Real-time Voice + Text Preview", "See the conversation text while talking with voice."],
  [Bot, "Lead Capture & Dashboard", "Collect name, email, phone and store them in your dashboard."],
  [Clock3, "24/7 Always Active", "Handles unlimited conversations anytime, even when you're away."],
  [Plug, "Easy Integration", "Works with any website, no coding skill required."],
];

const languages = ["🇺🇸 English", "🇪🇸 Spanish", "🇫🇷 French", "🇩🇪 German", "🇸🇦 Arabic", "🇮🇳 Hindi", "🇨🇳 Chinese", "🇯🇵 Japanese", "🇧🇩 Bengali", "🇵🇹 Portuguese", "🇮🇹 Italian", "🌐 +100 More"];
const platforms = ["Website", "Facebook", "Instagram", "WhatsApp", "Messenger", "Shopify", "WooCommerce", "WordPress", "Zapier", "More"];

function VoiceWidget() {
  const bars = Array.from({ length: 30 });
  return (
    <div className="voice-visual">
      <div className="voice-widget-glow" />
      <div className="voice-phone">
        <div className="voice-phone-top"><Volume2 size={14}/><span>◌</span><X size={14}/></div>
        <div className="voice-avatar"><Bot size={31}/></div>
        <strong>Fexa AI Agent</strong>
        <small>Online</small>
        <div className="voice-timer">00:24</div>
        <div className="voice-wave">{bars.map((_, i) => <i key={i} style={{ animationDelay: `${i * 0.035}s`, height: `${8 + ((i * 13) % 19)}px` }} />)}</div>
        <small className="talking">• Talking •</small>
        <div className="voice-controls"><button><Mic2 size={14}/><span>Mute</span></button><button className="hang"><Phone size={17}/></button><button><SquareIcon/><span>End Call</span></button></div>
        <div className="powered">Powered by Fexa Agent</div>
      </div>
      <div className="voice-chat-preview">
        <div className="chat-bubble user">Do you have this product in black color?</div>
        <div className="mini-agent"><span><Bot size={14}/></span><div><b>Fexa AI</b><small>00:13</small><p>Yes! This product is available in black color. Let me show you.</p></div></div>
        <div className="mini-agent"><span><Bot size={14}/></span><div><b>Fexa AI</b><small>00:15</small><p>Opening the product page for you now...</p><div className="product-card"><div className="shirt"/><div><b>Men Premium Cotton Jacket</b><small>$320.00</small><button>View Product →</button></div></div></div></div>
      </div>
    </div>
  );
}

function SquareIcon(){ return <span className="square-icon"/> }

function VoiceSectionTitle({ eyebrow, children }) {
  return <><div className="voice-eyebrow">{eyebrow}</div><h2>{children}</h2></>;
}

function AIVoicePage(){
  return <main className="ai-voice-page">
    <section className="voice-hero">
      <div className="voice-grid"/><div className="voice-orb orb-a"/><div className="voice-orb orb-b"/>
      <div className="voice-container voice-hero-inner">
        <div className="voice-hero-copy">
          <div className="voice-eyebrow">AI POWERED</div>
          <h1>AI <span>Voice Chat</span> Agent</h1>
          <h3>Let your website talk to your customers.</h3>
          <p>Give your visitors a natural voice conversation experience that can answer questions, show products or pages, book appointments and guide them — 24/7 in any language.</p>
          <div className="voice-actions"><button className="voice-primary">Book a Demo <ArrowRight size={15}/></button><button className="voice-secondary">Start Free Trial</button></div>
          <div className="hero-checks"><span><Check/> No credit card required</span><span><Check/> Setup in minutes</span><span><Check/> Cancel anytime</span></div>
        </div>
        <VoiceWidget/>
      </div>
    </section>

    <section className="voice-usecases voice-container">
      <VoiceSectionTitle eyebrow="USE CASES">Perfect for Every <span>Business.</span></VoiceSectionTitle>
      <p className="section-sub">Use AI Voice Chat on any type of website to engage visitors and increase conversions.</p>
      <div className="usecase-grid">{useCases.map(([title,desc],i)=><div className="usecase" key={title}><div className={`use-img use-${i}`}/><div><b>{title}</b><small>{desc}</small></div></div>)}</div>
      <div className="metric-row"><div><b>5x</b><small>Faster Response</small></div><div><b>24/7</b><small>Customer Support</small></div><div><b>10x</b><small>More Conversions</small></div><div><b>99.9%</b><small>Uptime & Reliability</small></div></div>
    </section>

    <section className="trusted-strip"><div className="voice-container"><small>TRUSTED BY 1,000+ BUSINESSES WORLDWIDE</small><div>{["WordPress","WooCommerce","Meta","Google","Zapier","Shopify"].map(x=><span key={x}>{x}</span>)}</div></div></section>

    <section className="voice-features voice-container">
      <div className="icon-feature-row">{[[Mic2,"Natural Human-like Voice"],[Globe2,"Multi-language Support"],[Clock3,"24/7 Always Active"],[Link2,"Guide to Products & Pages"],[MessageCircle,"Social Media Connection"],[Users,"Capture Leads in Dashboard"]].map(([Icon,t])=><div key={t}><Icon/><span>{t}</span></div>)}</div>
    </section>

    <section className="voice-demo-section voice-container"><div className="demo-copy"><VoiceSectionTitle eyebrow="WATCH & LEARN">See How AI Voice Chat<br/>Works for <span>Your Business.</span></VoiceSectionTitle><p>Watch the full step-by-step demonstration to see how Fexa Agent handles customer conversations, finding products, navigating pages, and converting visitors into customers — automatically.</p><button className="voice-primary"><span className="play">▶</span> Play Full Demo Video (03:45)</button></div><div className="demo-laptop"><div className="laptop-screen"><div className="fake-nav">Fexa Agents <span>Platform　 Solutions　 Features　 Pricing</span></div><div className="fake-page"><h3>AI Voice Chat Agent</h3><b>Full Demo</b><div className="fake-play">▶</div></div><VoiceWidget/></div></div></section>

    <section className="how-section voice-container"><VoiceSectionTitle eyebrow="SIMPLE SETUP">How AI Voice Chat Works</VoiceSectionTitle><p className="section-sub left">Get started in minutes and let Fexa Agent handle the rest.</p><div className="steps">{[["01",Bot,"Add to Your Website","Install the voice widget on your website in minutes."],["02",Users,"Visitor Signs Up","Customer gives name, email and phone number to start the call."],["03",Mic2,"AI Starts Talking","Our AI agent starts a natural voice conversation with real-time text preview."],["04",MessageCircle,"Guide & Solve","Answers questions, shows products or pages and guides the customer."]].map(([n,Icon,t,d],i)=><React.Fragment key={n}><div className="step"><b>{n}</b><Icon/><h3>{t}</h3><p>{d}</p></div>{i<3&&<ArrowRight className="step-arrow"/>}</React.Fragment>)}</div></section>

    <section className="language-section"><div className="voice-container language-inner"><div><VoiceSectionTitle eyebrow="GLOBAL REACH">Speaks Your<br/>Customer's <span>Language</span></VoiceSectionTitle><p>Our AI voice agent supports 100+ languages. Customers can speak in any language and the agent will respond in the same language with a natural, human-like voice.</p></div><div className="language-grid">{languages.map(x=><span key={x}>{x}</span>)}</div></div></section>

    <section className="lead-section voice-container"><div className="channel-card"><VoiceSectionTitle eyebrow="OMNICHANNEL">Connect Across Channels</VoiceSectionTitle><p>From your website to social media—let your customers connect with your AI voice agent anywhere.</p><div className="channel-icons"><span><Globe2/>Website</span><span><FaFacebookF/>Facebook</span><span><FaInstagram/>Instagram</span><span><MessageCircle/>WhatsApp</span><span><MessageCircle/>Messenger</span><span><MoreHorizontal/>More</span></div></div><div className="lead-card"><VoiceSectionTitle eyebrow="LEAD MANAGEMENT">Automatically Capture Leads</VoiceSectionTitle><p>All visitor information (name, email, phone, call history) is saved in your dashboard. Easily view, manage and follow up with high-intent leads.</p><div className="lead-table"><b>Name　　Phone　　　 Email　　　　　 Time　 Status</b><span>Jannatul Shayla　 +1 349-538-7845　 fexa@gmail.com　　 2 min ago　 <i>New</i></span><span>Michael Carter　 +1 202-555-0194　 michael@example.com　 12 min ago　 <i>Contacted</i></span><span>Emily Smith　　 +1 416-555-2678　 emily@gmail.com　　 1 hour ago　 <i>Qualified</i></span><span>David Wilson　 +1 312-555-8642　 david@example.com　 1 hour ago　 <i>New</i></span></div></div></section>

    <section className="key-features voice-container"><VoiceSectionTitle eyebrow="KEY FEATURES">Powerful Features for Better <span>Customer Experience.</span></VoiceSectionTitle><div className="feature-grid">{features.map(([Icon,t,d])=><div className="feature-card" key={t}><Icon/><h3>{t}</h3><p>{d}</p></div>)}</div></section>

    <section className="infra-section voice-container"><div className="infra-copy"><VoiceSectionTitle eyebrow="POWERED BY OFFICIAL APIS">Reliable AI Infrastructure<br/>Behind Every Conversation.</VoiceSectionTitle><p>Fexa Agent uses industry-leading AI models and services with official APIs to deliver fast, accurate and human-like voice conversations.</p><div className="api-grid">{[[Bot,"OpenAI","ChatGPT"],[Sparkles,"Claude","Anthropic Claude"],[Zap,"Gemini","Google Gemini"],[Volume2,"ElevenLabs","Voice AI"],[Bot,"Server","Infrastructure"],[Globe2,"Web & Data","Access"]].map(([Icon,t,s])=><div key={t}><Icon/><b>{t}</b><small>{s}</small></div>)}</div></div><div className="architecture"><div className="arch-flow"><span>Website Visitor</span><ArrowRight/><span>Voice Input<br/><small>(Speech to Text)</small></span><ArrowRight/><strong>AI Processing<br/><small>(OpenAI / Claude / Gemini)</small></strong><ArrowRight/><span>Voice Output<br/><small>(Text to Speech)</small></span></div><div className="arch-bottom"><span>Website Data<br/><small>Pages & Products</small></span><span>Server<br/><small>Secure & Scalable</small></span><span>Store Leads<br/><small>Name, Email, Phone</small></span></div></div></section>

    <section className="integrate-section voice-container"><VoiceSectionTitle eyebrow="CONNECT EVERYWHERE">Integrate with Popular <span>Platforms.</span></VoiceSectionTitle><p className="section-sub">Connect your website and social media channels to provide a seamless experience.</p><div className="platform-row">{platforms.map((x,i)=><div key={x}><span>{i===0?<Globe2/>:i===1?<FaFacebookF/>:i===2?<FaInstagram/>:i===3?<MessageCircle/>:<Plug/>}</span>{x}</div>)}</div></section>

    <section className="testimonial-section"><div className="voice-container"><VoiceSectionTitle eyebrow="TESTIMONIALS">What our clients say about Fexa <span>Agent.</span></VoiceSectionTitle><p className="section-sub">Real businesses. Real teams. Real results powered by intelligent automation.</p><div className="testimonial-main"><button><ChevronLeft/></button><div><div className="quote">99</div><div className="stars">★★★★★</div><p>“The recruitment agent screens and ranks every applicant automatically. What used to take our team days now takes hours.”</p><b>Daniel Kim</b><small>Head of Engineering</small></div><button><ChevronRight/></button></div><div className="testimonial-mini">{["E-commerce businesses.","Hiring is now 10x easier with the AI Recruiter.","The AI voice agent handles calls perfectly.","A must-have for every team."].map((x,i)=><div key={i}><span>★★★★★</span><p>{x}</p><b>{["Daniel Kim","Daniel Kim","Rachel Adams","Chris Taylor"][i]}</b></div>)}</div></div></section>

    <section className="faq-section voice-container"><VoiceSectionTitle eyebrow="">Frequently asked questions</VoiceSectionTitle><p className="section-sub">Everything you need to know about Fexa Agent.</p><div className="faq-list">{["How does Fexa Agent work?","Do I need technical knowledge to get started?","Which platforms does it support?","Can I try Fexa Agent for free?","Is my data secure?"].map((q,i)=><details key={q} open={i===0}><summary>{q}<span>{i===0?"−":"+"}</span></summary>{i===0&&<p>Fexa Agent uses advanced AI to understand customer inquiries, automate workflows and perform tasks like chatting, calling and recruitment — all from one powerful platform.</p>}</details>)}</div></section>

    <footer className="voice-footer"><div className="voice-container"><div><b className="footer-brand"><Bot/> Fexa Agent</b><p>AI agents for modern business.<br/>Automate. Engage. Grow.</p><div className="footer-social"><FaFacebookF/><FaInstagram/><Send/><MoreHorizontal/></div></div><div><b>Product</b><span>AI Chat</span><span>AI Recruiter</span><span>AI Voice</span><span>AI Solutions</span><span>Integrations</span></div><div><b>Company</b><span>About</span><span>Careers</span><span>Blog</span><span>Contact</span></div><div><b>Resources</b><span>Help Center</span><span>Documentation</span><span>Case Studies</span><span>Pricing</span></div></div></footer>
  </main>
}

export default AIVoicePage;
